  *Dont remove this file*
 - in this file all bots will be in
